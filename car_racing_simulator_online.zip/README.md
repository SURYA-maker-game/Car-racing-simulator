# CAR RACING SIMULATOR — Online Edition

A browser racing game starter featuring:
- Fantasy-style perspective racing track
- Five selectable cars in a garage
- Practice mode
- Online rooms for up to four players
- Shared player list and live score/position updates
- Checkpoints, diamonds, drifting smoke, nitro and minimap
- Achievement display

## Run locally

You need Node.js installed.

```bash
npm install
npm start
```

Open http://localhost:3000

## Test multiplayer locally

1. Open the game in two browser tabs (or two devices on the same network using your computer's LAN IP).
2. Enter a racer name in each tab.
3. Enter the same room code, such as `RACE01`.
4. Press **JOIN ONLINE ROOM** in both tabs.
5. Start a practice race. Opponents appear on the track and the lobby shows live scores.

## Publish online

Deploy this folder to a Node.js hosting provider that supports persistent processes and WebSocket connections. Set the start command to `npm start`. The host should provide HTTPS and support Socket.IO/WebSockets. Then share the public URL with friends.

## Important notes

- The online server synchronizes room membership and player state. This starter does not yet provide authoritative physics, synchronized race starts, anti-cheat validation, persistent accounts, or a global leaderboard.
- Scores and achievements currently live in the browser session; they are not saved to an account or database.
- The displayed rival cars are visual representations of other players' latest reported positions, not a fully physics-synchronized shared 3D simulation.
- For a public launch, add server-side race validation, rate limits, moderation/reporting, privacy controls, and persistent storage.
