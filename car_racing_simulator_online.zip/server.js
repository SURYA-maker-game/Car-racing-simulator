const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: true },
  maxHttpBufferSize: 1e5
});

const PORT = process.env.PORT || 3000;
const rooms = new Map();
app.use(express.static("public"));

function cleanName(value) {
  return String(value || "Racer").replace(/[<>]/g, "").trim().slice(0, 16) || "Racer";
}
function validRoom(value) {
  return /^[A-Z0-9]{4,8}$/.test(String(value || "").toUpperCase());
}
function playersIn(room) {
  return [...(rooms.get(room)?.values() || [])].map(p => ({
    id: p.id, name: p.name, car: p.car,
    score: p.score, coins: p.coins, x: p.x,
    progress: p.progress, drifting: p.drifting
  }));
}
function emitRoom(room) {
  io.to(room).emit("players", playersIn(room));
}

io.on("connection", socket => {
  socket.data.room = null;

  socket.on("joinRoom", payload => {
    const name = cleanName(payload?.name);
    const room = String(payload?.room || "").toUpperCase();

    if (!validRoom(room)) {
      socket.emit("roomError", "Use a 4–8 character room code (letters/numbers).");
      return;
    }
    if (socket.data.room === room) return;

    const oldRoom = socket.data.room;
    if (oldRoom && rooms.has(oldRoom)) {
      rooms.get(oldRoom).delete(socket.id);
      socket.leave(oldRoom);
      if (rooms.get(oldRoom).size === 0) rooms.delete(oldRoom);
      else emitRoom(oldRoom);
    }

    if (!rooms.has(room)) rooms.set(room, new Map());
    const members = rooms.get(room);
    if (members.size >= 4) {
      socket.emit("roomError", "This room is full (maximum 4 racers).");
      return;
    }

    socket.data.room = room;
    socket.join(room);
    members.set(socket.id, {
      id: socket.id, name, car: "Thunder GT",
      score: 0, coins: 0, x: 0, progress: 0, drifting: false
    });
    socket.emit("joinedRoom", { room, playerId: socket.id });
    emitRoom(room);
  });

  socket.on("raceUpdate", data => {
    const room = socket.data.room;
    if (!room || !rooms.has(room)) return;
    const player = rooms.get(room).get(socket.id);
    if (!player) return;

    const number = (v, min, max) => Math.max(min, Math.min(max, Number(v) || 0));
    player.score = number(data?.score, 0, 1000000);
    player.coins = number(data?.coins, 0, 100000);
    player.x = number(data?.x, -160, 160);
    player.progress = number(data?.progress, 0, 1000000);
    player.drifting = Boolean(data?.drifting);
    player.car = cleanName(data?.car || "Thunder GT").slice(0, 24);

    // Broadcast the latest positions and standings to everyone in the room.
    emitRoom(room);
  });

  socket.on("leaveRoom", () => leave());
  function leave() {
    const room = socket.data.room;
    if (!room) return;
    socket.leave(room);
    socket.data.room = null;
    if (rooms.has(room)) {
      rooms.get(room).delete(socket.id);
      if (rooms.get(room).size === 0) rooms.delete(room);
      else emitRoom(room);
    }
  }

  socket.on("disconnect", leave);
});

app.get("/health", (_req, res) => res.json({ ok: true, game: "CAR RACING SIMULATOR" }));

server.listen(PORT, () => {
  console.log(`CAR RACING SIMULATOR running on http://localhost:${PORT}`);
});
